/**
* MyPyramid
* @constructor
*/
class MyTree extends CGFobject {
    constructor(scene, trunkHeight, trunkRadius, treeTopHeight, treeTopRadius) {
        super(scene);
        this.cylinder = new MyCylinder(scene, 10);
        this.cone = new MyCone(scene, 10);
        this.trunkH= trunkHeight;
        this.trunkR =trunkRadius;
        this.topHeight= treeTopHeight;
        this.topRadius= treeTopRadius;

        this.treeTopMaterial = new CGFappearance(this.scene);
        this.treeTopMaterial.setAmbient(0.3, 0.3, 0.3, 1);
        this.treeTopMaterial.setDiffuse(1.0, 1.0, 1.0, 1);
        this.treeTopMaterial.setSpecular(1.0, 1.0, 1.0, 1);
        this.treeTopMaterial.setShininess(10.0);
        this.treeTopMaterial.loadTexture('images/treeTop.jpg');
        this.treeTopMaterial.setTextureWrap('REPEAT', 'REPEAT');
    }

   display()
    {
        this.scene.pushMatrix();
        this.scene.scale(this.trunkR, this.trunkH, this.trunkR);
        this.scene.trunkMaterial.apply();
		this.cylinder.display();
        this.scene.popMatrix(); 
        
        this.scene.pushMatrix();
        this.scene.translate(0,this.trunkH,0);
        this.scene.scale(this.topRadius, this.topHeight, this.topRadius);
        this.treeTopMaterial.apply();
		this.cone.display();
        this.scene.popMatrix(); 
    
    }
    

}


