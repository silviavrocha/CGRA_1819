/**
* MyInterface
* @constructor
*/
class MyInterface extends CGFinterface {
    constructor() {
        super();
    }

    init(application) {
        // call CGFinterface init
        super.init(application);
        // init GUI. For more information on the methods, check:
        // http://workshop.chromeexperiments.com/examples/gui
        this.gui = new dat.GUI();

          
        // // similar but for light 1
        // var f1 = this.gui.addFolder('Sun');
        // f1.add(this.scene.lights[0], 'enabled').name("Enabled");
        // var sf1 = f1.addFolder('Sun Position');
        // sf1.add(this.scene.lights[0].position, '0', -50.0, 50.0).name("X Position");
        // sf1.add(this.scene.lights[0].position, '1', 0.0, 100.0).name("Y Position");
        // sf1.add(this.scene.lights[0].position, '2', -50.0, 50.0).name("Z Position");
        // var sf2 = f1.addFolder('Sun Attenuation');
        // sf2.add(this.scene.lights[0], 'constant_attenuation', 0.00, 1.00).name("Const. Atten.");
        // sf2.add(this.scene.lights[0], 'linear_attenuation', 0.0, 1.0).name("Linear Atten.");
        // sf2.add(this.scene.lights[0], 'quadratic_attenuation', 0.0, 1.0).name("Quad. Atten.");
        
        // var f1 = this.gui.addFolder('Moon');
        // f1.add(this.scene.lights[1], 'enabled').name("Enabled");
        // var sf1 = f1.addFolder('Moon Position');
        // sf1.add(this.scene.lights[1].position, '0', -50.0, 50.0).name("X Position");
        // sf1.add(this.scene.lights[1].position, '1', 0.0, 100.0).name("Y Position");
        // sf1.add(this.scene.lights[1].position, '2', -50.0, 50.0).name("Z Position");
        // var sf2 = f1.addFolder('Moon Attenuation');
        // sf2.add(this.scene.lights[1], 'constant_attenuation', 0.00, 1.00).name("Const. Atten.");
        // sf2.add(this.scene.lights[1], 'linear_attenuation', 0.0, 1.0).name("Linear Atten.");
        // sf2.add(this.scene.lights[1], 'quadratic_attenuation', 0.0, 1.0).name("Quad. Atten.");

        this.gui.add(this.scene.lights[2], 'enabled').name("Enable Fireplace");

        var obj = this;

        this.gui.add(this.scene,'displaytextures').name('Display Textures').onChange(this.scene.updateTextures.bind(this.scene));

        this.gui.add(this.scene, 'timemode', this.scene.modeIds).name('Time Mode').onChange(this.scene.updateTimeMode.bind(this.scene));


        return true;
    }
}