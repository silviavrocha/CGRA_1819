// VoxelHill

class MyPool extends CGFobject {
    constructor(scene) {
        super(scene);
        this.border = new MyUnitCubeQuad(scene, scene.wallMaterials);
        this.poolQuad = new MyQuad(scene);
        
        this.poolMaterial = new CGFappearance(this.scene);    //specular material
        this.poolMaterial.setAmbient(230/255,228/255,216/255, 1.0);
        this.poolMaterial.setDiffuse(0, 0, 0, 1.0);
        this.poolMaterial.setSpecular(230/255,228/255,216/255, 1.0);
        this.poolMaterial.setShininess(10.0);
        this.poolMaterial.loadTexture('images/pool.jpg');
        this.poolMaterial.setTextureWrap('REPEAT', 'REPEAT');
    }

    display() {
        //back of the pool
        this.scene.pushMatrix();
        this.scene.translate(-4, 0, -3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-3, 0, -3);
        this.border.display();
        this.scene.popMatrix();
        
        this.scene.pushMatrix();
        this.scene.translate(-2, 0, -3);
        this.border.display();
        this.scene.popMatrix();
     
        this.scene.pushMatrix();
        this.scene.translate(-1, 0, -3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, 0, -3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(1, 0, -3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(2, 0, -3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(3, 0, -3);
        this.border.display();
        this.scene.popMatrix();

        //front of the pool
        this.scene.pushMatrix();
        this.scene.translate(-4, 0, 3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-3, 0, 3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-2, 0, 3);
        this.border.display();
        this.scene.popMatrix();
        
        this.scene.pushMatrix();
        this.scene.translate(-1, 0, 3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0, 0, 3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(1, 0, 3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(2, 0, 3);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(3, 0, 3);
        this.border.display();
        this.scene.popMatrix();
        
        //sides
        this.scene.pushMatrix();
        this.scene.translate(3, 0, -2);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(3, 0, -1);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(3, 0, 0);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(3, 0, 1);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(3, 0, 2);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-4, 0, -2);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-4, 0, -1);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-4, 0, 0);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-4, 0, 1);
        this.border.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(-4, 0, 2);
        this.border.display();
        this.scene.popMatrix();

        //inside
        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2,1,0,0);
        this.scene.scale(7,6,1);
        this.scene.translate(0,0,0.3);
        this.poolMaterial.apply();
        this.poolQuad.display();
        this.scene.popMatrix();
    }
}