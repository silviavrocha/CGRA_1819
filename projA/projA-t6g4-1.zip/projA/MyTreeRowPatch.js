/**
* MyPyramid
* @constructor
*/
class MyTreeRowPatch extends CGFobject {
    constructor(scene){
        super(scene);
        this.trunkRadius = 0.5;
        this.tree1 = new MyTree(scene,1.8,this.trunkRadius,2,0.8);
        this.tree2 = new MyTree(scene,1.9,this.trunkRadius+Math.random()/4,2.1,1);
        this.tree3 = new MyTree(scene,1.7,this.trunkRadius-Math.random()/4,1.8,0.7);

        this.deviation=new Array(6);   
		          
        for (var i=0; i <6; i++){                          
                    this.deviation[i] = Math.random() * (2 * this.trunkRadius); 
            }
    }

    display()
    {   
        this.scene.pushMatrix();
		this.scene.translate(- 3 * this.trunkRadius + this.deviation[0], 0, this.deviation[0]);
		this.tree1.display();
		this.scene.popMatrix();

		this.scene.pushMatrix();
		this.scene.translate(3 * this.trunkRadius + this.deviation[1], 0, this.deviation[1]);
		this.tree3.display();
		this.scene.popMatrix();
        
		this.scene.pushMatrix();
		this.scene.translate(9 * this.trunkRadius + this.deviation[2], 0, this.deviation[2]);
		this.tree2.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(-9 * this.trunkRadius + this.deviation[3], 0, this.deviation[3]);
		this.tree2.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(15 * this.trunkRadius  + this.deviation[4], 0, this.deviation[4]);
		this.tree3.display();
		this.scene.popMatrix();

		this.scene.pushMatrix();
		this.scene.translate(-15 * this.trunkRadius  + this.deviation[5], 0, this.deviation[5]);
		this.tree1.display();
		this.scene.popMatrix();

    }
    

}


