// VoxelHill

class MyVoxelHill extends CGFobject {
    constructor(scene, levels) {
        super(scene);
        
        this.sidesMaterial = new CGFappearance(this.scene);
        this.sidesMaterial.setAmbient(0.3, 0.3, 0.3, 1);
        this.sidesMaterial.setDiffuse(1.0, 1.0, 1.0, 1);
        this.sidesMaterial.setSpecular(1.0, 1.0, 1.0, 1);
        this.sidesMaterial.setShininess(10.0);
        this.sidesMaterial.loadTexture('images/mineSide.png');
        this.sidesMaterial.setTextureWrap('REPEAT', 'REPEAT');

        this.levels = levels;
        this.cube = new MyUnitCubeQuad(scene, this.sidesMaterial);
    }

    display() {
        for (var i = 0; i < this.levels; i++) {
            let length = 2 * i + 1;

            for (var k = 0; k < length; k++) {
                this.scene.pushMatrix();
                this.scene.translate(-i, this.levels - i, -i);
                this.cube.display();
                this.scene.popMatrix();
            }

            for (var k = 0; k < length; k++) {
                this.scene.pushMatrix();
                this.scene.translate(-i, this.levels - i, i);
                this.cube.display();
                this.scene.popMatrix();
            }

            for (var k = 0; k < length; k++) {
                this.scene.pushMatrix();
                this.scene.translate(-i, this.levels - i, -i + k);
                this.cube.display();
                this.scene.popMatrix();

                this.scene.pushMatrix();
                this.scene.translate(i, this.levels - i, -i + k);
                this.cube.display();
                this.scene.popMatrix();

                this.scene.pushMatrix();
                this.scene.translate(-i+k, this.levels - i, -i);
                this.cube.display();
                this.scene.popMatrix();

                this.scene.pushMatrix();
                this.scene.translate(-i+k, this.levels - i, i);
                this.cube.display();
                this.scene.popMatrix();
            }
        }
    }
}