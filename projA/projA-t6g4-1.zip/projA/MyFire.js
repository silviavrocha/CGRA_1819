/**
* MyPyramid
* @constructor
*/
class MyFire extends CGFobject {
    constructor(scene) {
        super(scene);
        this.quad = new MyQuad(scene);
        this.prism= new MyPrism(scene, 4, 1);
        this.cone =new MyCone(scene,20,1);

        this.fireMaterial = new CGFappearance(this.scene);
        this.fireMaterial.setAmbient(0.3, 0.3, 0.3, 1);
        this.fireMaterial.setDiffuse(1.0, 1.0, 1.0, 1);
        this.fireMaterial.setSpecular(1.0, 1.0, 1.0, 1);
        this.fireMaterial.setShininess(10.0);
        this.fireMaterial.loadTexture('images/fire.jpg');
        this.fireMaterial.setTextureWrap('REPEAT', 'REPEAT');
    }

   display()
    {
        this.scene.pushMatrix();
        this.scene.scale(1.5,1.5,1.5);
        this.scene.translate(0,0.5,3.5);
        this.fireMaterial.apply();
        this.cone.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2,1,0,0);
        this.scene.rotate(Math.PI/4,0,1,0);
        this.scene.scale(1,10,1);
        this.scene.trunkMaterial.apply();
		this.prism.display();
        this.scene.popMatrix();     

        this.scene.pushMatrix();
        this.scene.scale(Math.sqrt(2),Math.sqrt(2),Math.sqrt(2));
        this.scene.translate(0,0,7);
        this.scene.trunkMaterial.apply();
		this.quad.display();
        this.scene.popMatrix();   
        
        this.scene.pushMatrix();
        this.scene.scale(Math.sqrt(2),Math.sqrt(2),Math.sqrt(2));
        this.scene.rotate(Math.PI, 1,0,0);
        this.scene.trunkMaterial.apply();
		this.quad.display();
        this.scene.popMatrix();    

        this.scene.rotate(Math.PI/6,0,1,0);
        this.scene.translate(-2.5,0,-1);

        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2,1,0,0);
        this.scene.rotate(Math.PI/4,0,1,0);
        this.scene.scale(1,10,1);
        this.scene.trunkMaterial.apply();
		this.prism.display();
        this.scene.popMatrix();     

        this.scene.pushMatrix();
        this.scene.scale(Math.sqrt(2),Math.sqrt(2),Math.sqrt(2));
        this.scene.translate(0,0,7);
        this.scene.trunkMaterial.apply();
		this.quad.display();
        this.scene.popMatrix();   
        
        this.scene.pushMatrix();
        this.scene.scale(Math.sqrt(2),Math.sqrt(2),Math.sqrt(2));
        this.scene.rotate(Math.PI, 1,0,0);
        this.scene.trunkMaterial.apply();
		this.quad.display();
        this.scene.popMatrix();
        
        this.scene.rotate(Math.PI/6,0,1,0);
        this.scene.translate(-3,0,0);

        this.scene.pushMatrix();
        this.scene.rotate(Math.PI/2,1,0,0);
        this.scene.rotate(Math.PI/4,0,1,0);
        this.scene.scale(1,10,1);
        this.scene.trunkMaterial.apply();
		this.prism.display();
        this.scene.popMatrix();     

        this.scene.pushMatrix();
        this.scene.scale(Math.sqrt(2),Math.sqrt(2),Math.sqrt(2));
        this.scene.translate(0,0,7);
        this.scene.trunkMaterial.apply();
		this.quad.display();
        this.scene.popMatrix();   
        
        this.scene.pushMatrix();
        this.scene.scale(Math.sqrt(2),Math.sqrt(2),Math.sqrt(2));
        this.scene.rotate(Math.PI, 1,0,0);
        this.scene.trunkMaterial.apply();
		this.quad.display();
        this.scene.popMatrix();  
    }
    
}


