/**
* MyPyramid
* @constructor
*/
class MyTreeGroupPatch extends CGFobject {
    constructor(scene) {

		super(scene);
        this.trunkHeight=2+Math.random()/2;
        this.trunkRadius=0.7+(Math.random()/4);
        this.treeTopHeight=1.5+Math.random();
        this.treeTopRadius=1+Math.random()/2;

        this.deviation=new Array(3);   

         for (var i=0; i <3; i++){          
			this.deviation[i]=new Array(3);
         }
         
         for (var i=0; i <3; i++){        
		 	for (var j=0; j <3; j++){                         
				this.deviation[i][j] = Math.random()/2; 
			}
        }

        this.tree1= new MyTree(scene,this.trunkHeight,this.trunkRadius, this.treeTopHeight,this.treeTopRadius);
        this.tree2= new MyTree(scene,this.trunkHeight+Math.random()/2,this.trunkRadius, this.treeTopHeight+Math.random()/3,this.treeTopRadius+Math.random()/4);
        this.tree3= new MyTree(scene,this.trunkHeight-Math.random()/2,this.trunkRadius-Math.random()/4, this.treeTopHeight-Math.random()/3,this.treeTopRadius-Math.random()/4);
    }

    display()
    {
        this.scene.pushMatrix();
		this.scene.translate(-1 -2 * this.trunkRadius + this.deviation[0][0], 0, -1-2*this.trunkRadius + this.deviation[0][0]);
		this.tree1.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(-1-2*this.trunkRadius + this.deviation[1][0], 0, this.deviation[1][0]);
		this.tree2.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(-1-2*this.trunkRadius+ this.deviation[2][0], 0 , 1+2*this.trunkRadius+ this.deviation[2][0]);
		this.tree3.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(this.deviation[0][1],0, -1-2*this.trunkRadius+ this.deviation[0][1]);
		this.tree3.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(this.deviation[1][1],0, this.deviation[1][1]);
		this.tree1.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(this.deviation[2][1],0, 1+2*this.trunkRadius+ this.deviation[2][1]);
		this.tree2.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(1+2*this.trunkRadius+ this.deviation[0][2],0, -1-2*this.trunkRadius+ this.deviation[0][2]);
		this.tree2.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(1+2*this.trunkRadius+ this.deviation[1][2],0, this.deviation[1][2]);
		this.tree3.display();
		this.scene.popMatrix();
		
		this.scene.pushMatrix();
		this.scene.translate(1+2*this.trunkRadius+ this.deviation[2][2],0, 1 + 2* this.trunkRadius+ this.deviation[2][2]);
		this.tree1.display();
        this.scene.popMatrix();
    }
    

}


