/**
* MyScene
* @constructor
*/
class MyScene extends CGFscene {
    constructor() {
        super();
    }
    init(application) {
        super.init(application);
        this.initCameras();
        this.initLights();

        //Background color
        this.gl.clearColor(0.0, 0.0, 0.0, 1.0);
        this.gl.clearDepth(100.0);
        this.gl.enable(this.gl.DEPTH_TEST);
        this.gl.enable(this.gl.CULL_FACE);
        this.gl.depthFunc(this.gl.LEQUAL);
        this.enableTextures(true);
       
        //Materials
        this.trunkMaterial = new CGFappearance(this);           //diffuse material
        this.trunkMaterial.setAmbient(85/255,60/255,42/255,1.0); 
        this.trunkMaterial.setDiffuse(85/255,60/255,42/255, 1.0);
        this.trunkMaterial.setSpecular(0, 0, 0, 1.0);
        this.trunkMaterial.setShininess(10.0);
        this.trunkMaterial.loadTexture('images/trunk.jpg');
        this.trunkMaterial.setTextureWrap('REPEAT', 'REPEAT');

        this.wallMaterials = new CGFappearance(this);
        this.wallMaterials.setAmbient(0.3, 0.3, 0.3, 1);
        this.wallMaterials.setDiffuse(1.0, 1.0, 1.0, 1);
        this.wallMaterials.setSpecular(1.0, 1.0, 1.0, 1);
        this.wallMaterials.setShininess(10.0);
        this.wallMaterials.loadTexture('images/wall.jpg');
        this.wallMaterials.setTextureWrap('REPEAT', 'REPEAT');

        this.cubeMapMaterial = new CGFappearance(this);
        this.cubeMapMaterial.setAmbient(0.6, 0.6, 0.6, 1);
        this.cubeMapMaterial.setDiffuse(1.0, 1.0, 1.0, 1);
        this.cubeMapMaterial.setSpecular(1.0, 1.0, 1.0, 1);
        this.cubeMapMaterial.setShininess(10.0);

        this.dayTexture = new CGFtexture(this,'images/day.png');
        this.nightTexture = new CGFtexture(this,'images/nightcube.jpg');
        
        this.grassMaterial = new CGFappearance(this);
        this.grassMaterial.setAmbient(0.3, 0.3, 0.3, 1);
        this.grassMaterial.setDiffuse(1.0, 1.0, 1.0, 1);
        this.grassMaterial.setSpecular(1.0, 1.0, 1.0, 1);
        this.grassMaterial.setShininess(10.0);
        this.grassMaterial.loadTexture('images/grass.jpg');
        this.grassMaterial.setTextureWrap('REPEAT', 'REPEAT');

        //Initialize scene objects
        this.floor = new MyQuad(this);
        this.treegroup = new MyTreeGroupPatch(this,this.trunkMaterial,this.treeTopMaterial);
        this.treerow = new MyTreeRowPatch(this,this.trunkMaterial,this.treeTopMaterial);
        this.house = new MyHouse(this);
        this.cubeMap = new MyCubeMap(this);
        this.hill = new MyVoxelHill(this,3);
        this.hill4 = new MyVoxelHill(this,7);
        this.pool= new MyPool(this);
        this.fire = new MyFire(this);

        this.displaytextures = true;
        this.timemode = 0;
        this.modeIds = { 'Day': 0, 'Night': 1 };
    }
    initLights() {
        this.setGlobalAmbientLight(0.6, 0.6, 0.6, 1.0);

        this.lights[0].setPosition(0, 100, 0, 1);    //sun
        this.lights[0].setAmbient(217/255, 217/255, 27/255, 1.0);
        this.lights[0].setDiffuse(217/255, 217/255, 59/255, 1.0);
        this.lights[0].setSpecular(217/255, 217/255, 27/255, 1.0); 
        this.lights[0].setLinearAttenuation(0.02);
        this.lights[0].enable();
        this.lights[0].update();

        this.lights[1].setPosition(0, 50, 0, 1);    //moon
        this.lights[1].setAmbient(32/255, 49/255, 1.0, 1.0);
        this.lights[1].setDiffuse(32/255, 49/255,1.0,1.0);
        this.lights[1].setSpecular(32/255,49/255,1.0,1.0);
        this.lights[1].setLinearAttenuation(0.2);
        this.lights[1].disable();
        this.lights[1].update();

        this.lights[2].setPosition(30, 0.5, -25, 1);    //fireplace
        this.lights[2].setAmbient(1.0,127/255,0.0);
        this.lights[2].setDiffuse(1.0, 127/255, 0.0, 1.0);
        this.lights[2].setSpecular(1.0,127/255,0.0,1.0);
        this.lights[2].setLinearAttenuation(0.8);        
        this.lights[2].disable();
        this.lights[2].setVisible(true);
        this.lights[2].update();
    }
    initCameras() {
        this.camera = new CGFcamera(0.4, 50, 500, vec3.fromValues(100, 50, 100), vec3.fromValues(0, 0, 0));
    }
    setDefaultAppearance() {
        this.setAmbient(0.2, 0.4, 0.8, 1.0);
        this.setDiffuse(0.2, 0.4, 0.8, 1.0);
        this.setSpecular(0.2, 0.4, 0.8, 1.0);
        this.setShininess(10.0);
    }

        updateTimeMode()
        {
            if (this.timemode == 0)
            {
                this.cubeMapMaterial.setTexture(this.dayTexture);
                this.lights[0].enable();
                this.lights[1].disable();
                this.lights[0].update();
                this.lights[1].update();
                this.lights[2].update();
            }
            if (this.timemode == 1)
            {
                this.cubeMapMaterial.setTexture(this.nightTexture);
                this.lights[0].disable();
                this.lights[1].enable();
                this.lights[0].update();
                this.lights[1].update();
                this.lights[2].update();
            }
        }

        updateTextures()
        {
            if(this.displaytextures)
                this.enableTextures(true);
            else
                this.enableTextures(false);
        }

    display() {
        // ---- BEGIN Background, camera and axis setup
        // Clear image and depth buffer everytime we update the scene
        this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
        this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
        // Initialize Model-View matrix as identity (no transformation
        this.updateProjectionMatrix();
        this.loadIdentity();
        // Apply transformations corresponding to the camera position relative to the origin
        this.applyViewMatrix();

        this.updateTimeMode();
        
        //Apply default appearance
        this.setDefaultAppearance();

         // ---- BEGIN Primitive drawing section
        this.pushMatrix();
        this.translate(0.5,0.5,0.5);
        this.scale(100,100,100);
        this.translate(0,0.485,0);
        this.cubeMapMaterial.apply();
        this.cubeMap.display();
        this.popMatrix();

        this.pushMatrix();
        this.rotate(-Math.PI/2,1,0,0);
        this.scale(100,100,1);
        this.translate(0.005,-0.005,0);
        this.grassMaterial.apply(); 
        this.floor.display();
        this.popMatrix();

        this.pushMatrix();
        this.rotate(-Math.PI/2,0,1,0);
        this.scale(7,7,7);
        this.house.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(2,2,2);
        this.translate(-15,-0.5,-15);
        this.hill4.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(5.2,2,3.5);
        this.translate(-5.75,-0.5,-2.4);
        this.hill.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(5.2,2,3.5);
        this.translate(-5.75,-0.5,2.4);
        this.hill.display();
        this.popMatrix();
        
        this.pushMatrix();
        this.scale(2,2,2);
        this.translate(-15,-0.5,15);
        this.hill4.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(2.5,2.5,2.5);
        this.rotate(Math.PI,0,1,0);
        this.translate(-10,0,-10);
        this.treerow.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(2.5,2.5,2.5);
        this.translate(10,0,13);
        this.treerow.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(1.5,1.5,1.5);
        this.translate(-6,0,-25);
        this.treegroup.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(2,2,2);
        this.translate(3.5,0,-20);
        this.treegroup.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(1.7,1.7,1.7);
        this.translate(23,0,-14);
        this.treegroup.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(1.9,1.9,1.9);
        this.translate(21,0,-21);
        this.treegroup.display();
        this.popMatrix();
        
        this.pushMatrix();
        this.scale(1.6,1.6,1.6);
        this.translate(9,0,-14);
        this.treegroup.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(1.8,1.8,1.8);
        this.translate(13.5,0,-22);
        this.treegroup.display();
        this.popMatrix();

        this.pushMatrix();
        this.rotate(Math.PI,0,0,1);
        this.scale(3,3,3);
        this.translate(-10,-0.5,0)
        this.pool.display();
        this.popMatrix();

        this.pushMatrix();
        this.scale(0.5,0.5,0.5);
        this.translate(54,0.5,-54);
        this.fire.display();
        this.popMatrix();
    
    // ---- END Primitive drawing section
    }
}